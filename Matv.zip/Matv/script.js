const imagesURL = chrome.extension.getURL("img");

const pathCage = imagesURL + '/qqq1.jpg';