let login1 = document.querySelector('#index_login_form, #login_form')

login1.innerHTML = '<input type="text" class="big_text" name="email" id="index_email" value="" placeholder="Иди учись!!1"> <a class="index_login_button flat_button button_big_text" href="https://www.netacad.com/ru" id="index_login_button" >Войти</a>'